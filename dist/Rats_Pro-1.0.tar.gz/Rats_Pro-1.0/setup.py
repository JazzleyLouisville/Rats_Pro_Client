from setuptools import setup, find_packages

setup(
    name="Rats_Pro",
    version="1.0",
    packages=find_packages()
)